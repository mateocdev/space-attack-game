# Recursos para la práctica 04

Recursos para las prácticas de ECS de la semana 4
